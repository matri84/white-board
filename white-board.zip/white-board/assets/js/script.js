const canvas = document.querySelector("canvas");
const ctx = canvas.getContext('2d');
const brushWidth = document.querySelector("#brush-width");
const brushColor = document.querySelector("#color");
const brush = document.querySelector(".brush");
const eraser = document.querySelector(".eraser");
const clearBtn = document.querySelector(".clear");
const save = document.querySelector(".save");

let isDrawing = false;
let curonWidth = 1;
let curontcolor = '';

window.addEventListener('load', () => {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    ctx.fillStyle = "white";
    ctx.fillRect(0,0,canvas.width,canvas.height);
})

function drawing(e){
    if(!isDrawing){
        return
    }
    ctx.lineTo(e.offsetX,e.offsetY);
    ctx.strokeStyle = `${curontcolor}`
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(e.offsetX, e.offsetY);
}

function startDraw(){
    isDrawing = true;
    ctx.beginPath();
    ctx.lineWidth = curonWidth;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
}

function stopDraw(){
    isDrawing = false;
}

canvas.addEventListener('mousemove', drawing);
canvas.addEventListener('mousedown', startDraw);
canvas.addEventListener('mouseup', stopDraw);
brushWidth.addEventListener('change', () =>{
    curonWidth = brushWidth.value;
})
brushColor.addEventListener('change', () =>{
    curontcolor = brushColor.value;
})
eraser.addEventListener('click',() => {
    eraser.classList.add("active");
    brush.classList.remove("active");
    curontcolor = 'white'
})
brush.addEventListener('click',() => {
    brush.classList.add("active");
    eraser.classList.remove("active");
    curontcolor = brushColor.value;
})
clearBtn.addEventListener('click',() => {
    ctx.fillStyle = "white";
    ctx.fillRect(0,0,canvas.width,canvas.height);
})
save.addEventListener('click',() => {
    let link = document.createElement('a');
    link.download = `${prompt("Please Enter File Name:")}.jpg`;
    link.href = canvas.toDataURL();
    link.click()
})